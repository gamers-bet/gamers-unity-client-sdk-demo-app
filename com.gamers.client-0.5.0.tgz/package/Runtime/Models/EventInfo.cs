using Gamers.Client.Models.Common;
using Newtonsoft.Json;
using System;

namespace Gamers.Client.Models
{
    /// <summary>Read-only event summary sent from the game-server for display.</summary>
    [Serializable]
    public class EventInfo
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("status")]
        public EventStatus Status { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }
    }
}
