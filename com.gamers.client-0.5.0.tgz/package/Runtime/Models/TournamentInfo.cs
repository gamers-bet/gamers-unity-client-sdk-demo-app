using Gamers.Client.Models.Common;
using Newtonsoft.Json;
using System;

namespace Gamers.Client.Models
{
    /// <summary>Read-only tournament summary sent from the game-server for display.</summary>
    [Serializable]
    public class TournamentInfo
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("status")]
        public TournamentStatus Status { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("entryFee")]
        public decimal EntryFee { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }
    }
}
