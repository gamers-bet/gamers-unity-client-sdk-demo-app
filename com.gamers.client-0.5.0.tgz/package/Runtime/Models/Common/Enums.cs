using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Runtime.Serialization;

namespace Gamers.Client.Models.Common
{
    /// <summary>Lifecycle status of an event, for display purposes.</summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EventStatus
    {
        [EnumMember(Value = "OPEN")] Open,
        [EnumMember(Value = "STARTED")] Started,
        [EnumMember(Value = "COMPLETED")] Completed,
        [EnumMember(Value = "REWARDED")] Rewarded,
        [EnumMember(Value = "CANCELLED")] Cancelled,
        [EnumMember(Value = "REFUNDED")] Refunded
    }

    /// <summary>Lifecycle status of a tournament, for display purposes.</summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TournamentStatus
    {
        [EnumMember(Value = "DRAFT")] Draft,
        [EnumMember(Value = "PENDING")] Pending,
        [EnumMember(Value = "OPENED")] Opened,
        [EnumMember(Value = "CLOSED")] Closed,
        [EnumMember(Value = "COMPLETED")] Completed,
        [EnumMember(Value = "CANCELLED")] Cancelled,
        [EnumMember(Value = "REFUNDED")] Refunded
    }
}
