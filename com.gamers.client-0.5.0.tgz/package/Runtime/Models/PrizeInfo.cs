using Newtonsoft.Json;
using System;

namespace Gamers.Client.Models
{
    /// <summary>Read-only prize information sent from the game-server for display.</summary>
    [Serializable]
    public class PrizeInfo
    {
        [JsonProperty("position")]
        public int Position { get; set; }

        [JsonProperty("amount")]
        public decimal Amount { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }
    }
}
