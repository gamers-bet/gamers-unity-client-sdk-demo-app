using Newtonsoft.Json;
using System;

namespace Gamers.Client
{
    /// <summary>Sent by the client when the player wants to join a tournament.</summary>
    [Serializable]
    public class JoinTournamentMessage : GamersClientMessage
    {
        [JsonProperty("type")]
        public override string Type => "tournament:join";

        /// <summary>The tournament identifier.</summary>
        [JsonProperty("tournamentId")]
        public string TournamentId { get; set; }

        public JoinTournamentMessage() { }

        public JoinTournamentMessage(string tournamentId)
        {
            TournamentId = tournamentId;
        }
    }
}
