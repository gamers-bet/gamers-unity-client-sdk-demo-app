using Newtonsoft.Json;
using System;

namespace Gamers.Client
{
    /// <summary>Sent by the client when the player wants to join an event.</summary>
    [Serializable]
    public class JoinEventMessage : GamersClientMessage
    {
        [JsonProperty("type")]
        public override string Type => "event:join";

        /// <summary>The event identifier.</summary>
        [JsonProperty("eventId")]
        public string EventId { get; set; }

        public JoinEventMessage() { }

        public JoinEventMessage(string eventId)
        {
            EventId = eventId;
        }
    }
}
