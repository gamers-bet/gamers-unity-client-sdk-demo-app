using Newtonsoft.Json;
using System;

namespace Gamers.Client
{
    /// <summary>Sent by the client when the player wants to start Gamers authentication.</summary>
    [Serializable]
    public class RequestAuthMessage : GamersClientMessage
    {
        [JsonProperty("type")]
        public override string Type => "auth:request";

        /// <summary>The email address to send the verification code to.</summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        public RequestAuthMessage() { }

        public RequestAuthMessage(string email)
        {
            Email = email;
        }
    }
}
