# Testing with the reference game server

The separately supplied reference server bridges a Unity transport to the test
Game API. Its archive contains its own setup instructions. This Unity package
contains an offline simulated sample, not a running server or WebSocket transport.

1. Start the server using its included README and configure it for `https://api.gamers.dev`.
2. Obtain a test session using the server's documented authentication setup.
3. Connect your Unity transport to the server's WebSocket address. Do not put the
   server's Game API key or shared token-issuing credentials in a distributed client.
4. Serialize the messages and deserialize the replies listed in the bundled
   [C# API reference](api-reference.md). Deliver replies on Unity's main thread.
5. Request an email code, verify it, and await an event or tournament join with
   a valid test competition ID. The fake sample's success replies do not validate
   these real server calls.

The reference server is a development example. Before using it for real players,
provide your own session authentication, persistent player sessions, authorization,
and server-validated scores. Its test token endpoint and practice scores are not
production authentication or trusted gameplay.

Use the [Reference Game-Server Guide](https://developer.gamers.dev/docs/reference-server-guide)
for startup, session tokens, WebSocket settings, and messages. It requires a developer
account. Use the bundled [integration guide](integration-guide.md) for Unity setup.
