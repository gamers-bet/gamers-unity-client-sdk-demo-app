# Gamers Client Integration Guide

Package: `com.gamers.client`<br>
Current package version: `1.0.0`<br>
Client-to-server protocol version: `1`

The **Gamers Client Helper** is a transport-agnostic Unity package for a server-authoritative Gamers integration. It provides five awaitable player operations, typed message contracts, a state machine, error handling, and read-only display models.

- [C# API reference](api-reference.md)

## 1. Requirements

| Requirement | Current value |
|---|---|
| Unity package minimum | Unity `2022.3.0`, as declared in `package.json` |
| API compatibility | .NET Standard 2.1 |
| Runtime dependency | `com.unity.nuget.newtonsoft-json` `3.2.1` |
| Game-server | Required; the package does not call the Gamers Game API |
| Client transport | Required implementation of `IGamersTransport` |
| Gamers configuration | A registered game and server-side Game API credentials |
| Editor attribution | Gamers developer ID entered under **Edit → Project Settings → Gamers** |

The developer's game-server owns Game API credentials, player authentication state, score validation, and all administrative operations. Never put a Game API key or player JWT in a client project.

## 2. Compatibility

| Target | Support |
|---|---|
| Unity | 2022.3 LTS or newer |
| Platforms | Windows, macOS, 64-bit Android (ARM64), and iOS |
| Scripting backends | Mono and IL2CPP |
| Render pipelines | Built-in, URP, and HDRP; the runtime contains no rendering code |

The package includes a `link.xml` that preserves `GamersClient.Runtime` and `GamersClient.Samples` from IL2CPP managed-code stripping.

## 3. Architecture and security boundary

```text
Unity client (GamersClientFlow + IGamersTransport)
  │ developer-owned networking
  ▼
Developer's game-server (Gamers Server SDK or equivalent)
  │ X-API-KEY and server-side player JWT
  ▼
Gamers Game API
```

The Unity client:

- requests authentication, event entry, tournament entry, and leaderboard data through the game-server
- contains no Game API URL, API key, or player JWT
- never submits trusted scores or results
- never creates, updates, completes, rewards, or cancels events or tournaments

The game-server:

- authenticates its own client session and derives the player identity from that session
- stores the Game API key and player JWT outside the client
- validates client input and authoritative gameplay results
- calls the Game API
- maps internal failures to safe `ErrorReply` values
- echoes the request `correlationId` and `protocolVersion` on every terminal reply

Event and tournament state are separate. Do not use an event identifier in a tournament message or infer one competition's state from the other.

## 4. Installation

### Local package

For an evaluation package supplied by Gamers:

1. Extract the package directory.
2. Open **Window → Package Manager**.
3. Select **+ → Add package from disk…**.
4. Select `package.json` at the root of the extracted package.

UPM resolves `com.unity.nuget.newtonsoft-json` automatically.

### Tarball

If Gamers supplies a `.tgz` package, import it through **Package Manager → Add package from tarball…**.

### Offline sample quick start

1. Select **Gamers Client Helper → Samples → Reference Integration → Import** in
   Package Manager.
2. Create an empty GameObject, add the imported `ReferenceIntegration` component,
   and enter Play mode so its session is initialized.
3. Connect your UI events to the handlers below. Pass input-field values through
   your UI handlers. `OnSubmitCode` takes both email and code, so call it from a
   handler that reads both fields.

| Order | Handler | Synthetic input | Expected Console output |
|---|---|---|---|
| 1 | `OnRequestAuth(email)` | `player@example.invalid` | Code-request acknowledgement |
| 2 | `OnSubmitCode(email, code)` | Same email and any test code | Authenticated reply |
| 3 | `OnJoinEvent(eventId)` | `sample-event` | An event entry ID |
| Alternative to 3 | `OnJoinTournament(tournamentId)` | `sample-tournament` | A tournament entry ID |
| 4 | `OnShowLeaderboard(tournamentId)` | `sample-tournament` | One sample leaderboard entry |

The sample's `ReferenceTransport` returns simulated success replies. It opens no
connection and creates no real email, account, entry, or payment. Use only
synthetic inputs because it logs messages. Successful sample output does not prove
a real game-server connection.

For a real game server, use the [reference server guide](https://developer.gamers.dev/docs/reference-server-guide)
and supply your own authenticated network transport. The sample includes no
WebSocket connection. Implement the adapter in section 6, then follow the sign-in
and join example in section 7.

### Assembly definitions

If your scripts use an assembly definition, reference `GamersClient.Runtime`.
A transport that calls Newtonsoft.Json also needs `Unity.Newtonsoft.Json`.
The sample can be removed from your project when you no longer need it.

## 5. Required game-server protocol

Every request and reply uses this envelope:

```json
{
  "type": "tournament:join",
  "protocolVersion": 1,
  "correlationId": "generated-by-gamers-client-flow"
}
```

The game-server must follow these rules:

1. Echo the request `correlationId` on exactly one terminal reply, including errors.
2. Echo `protocolVersion: 1`.
3. Omit `correlationId` only for a deliberate unsolicited push.
4. Return player-safe errors. Never forward stack traces, credentials, internal URLs, or raw provider errors.
5. Derive the player from the authenticated game-server session, not from a client-supplied player identifier.
6. Keep event and tournament handlers, identifiers, and authorization checks separate.

A missing terminal reply becomes `TimeoutException`. A duplicate or late reply cannot complete a newer request. A mismatched reply type becomes `GamersClientException` with code `PROTOCOL_MISMATCH`. A version other than `1` becomes `UNSUPPORTED_PROTOCOL_VERSION`.

## 6. Implement `IGamersTransport`

The package does not choose a networking stack. Implement `IGamersTransport` with Netcode for GameObjects, Mirror, Photon, WebSockets, REST, or the game's existing client/server channel.

The adapter below is complete C# but does not open a connection. Supply your game's
send function and main-thread dispatcher, then pass received JSON to `ReceiveJson`.
Handle malformed or unsupported messages at the connection boundary.

```csharp
using Gamers.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Threading;
using System.Threading.Tasks;

public sealed class JsonGamersTransport : IGamersTransport
{
    private readonly Func<string, CancellationToken, Task> _send;
    private readonly Action<Action> _dispatchToMainThread;

    public event Action<GamersServerReply> ReplyReceived;

    public JsonGamersTransport(
        Func<string, CancellationToken, Task> send,
        Action<Action> dispatchToMainThread)
    {
        _send = send ?? throw new ArgumentNullException(nameof(send));
        _dispatchToMainThread = dispatchToMainThread
            ?? throw new ArgumentNullException(nameof(dispatchToMainThread));
    }

    public Task SendAsync(GamersClientMessage message, CancellationToken ct = default)
        => _send(JsonConvert.SerializeObject(message), ct);

    public void ReceiveJson(string json)
    {
        var payload = JObject.Parse(json);
        GamersServerReply reply = (string)payload["type"] switch
        {
            "auth:code-requested" => payload.ToObject<AuthCodeRequestedReply>(),
            "auth:result" => payload.ToObject<AuthResultReply>(),
            "event:join-result" => payload.ToObject<EventJoinResultReply>(),
            "tournament:join-result" => payload.ToObject<TournamentJoinResultReply>(),
            "tournament:leaderboard" => payload.ToObject<LeaderboardSnapshotReply>(),
            "error" => payload.ToObject<ErrorReply>(),
            _ => throw new JsonSerializationException("Unsupported game-server reply type")
        };
        _dispatchToMainThread(() => ReplyReceived?.Invoke(reply));
    }
}
```

`SendAsync` completes when the message has been accepted by the transport. The
operation returned by `GamersClientFlow` completes after `ReplyReceived` delivers
the matching reply. Connect and authenticate the transport before starting that flow.
If all networking callbacks already run on Unity's main thread, the dispatcher
can be `action => action()`; otherwise use your main-thread scheduling mechanism.

## 7. Use `GamersClientFlow`

Create one flow for a connected client session. The example below requests an email
code, waits for your UI to collect it, verifies it, and joins one event. Supply an
event ID made available by your game server and handle failures at the awaited call.

```csharp
using Gamers.Client;
using System;
using System.Threading;
using System.Threading.Tasks;

public static class GamersJourney
{
    public static async Task<EventJoinResultReply> SignInAndJoinEventAsync(
        IGamersTransport transport,
        string email,
        Func<CancellationToken, Task<string>> collectCode,
        string eventId,
        CancellationToken ct)
    {
        using var flow = new GamersClientFlow(transport)
        {
            RequestTimeout = TimeSpan.FromSeconds(30)
        };
        await flow.RequestAuthAsync(email, ct);
        var code = await collectCode(ct);
        await flow.SubmitCodeAsync(email, code, ct);
        return await flow.JoinEventAsync(eventId, ct);
    }
}
```

`collectCode` is your code-entry UI; it returns the code the player received and
supports cancellation. The game server holds the resulting player authentication.
In an ongoing scene, keep the flow alive for later joins and leaderboard requests,
and dispose it when the session ends. Cancel the scene's token before disposal.
Subscribe to `OnStateChanged`, `OnAuthenticated`, `OnEventJoined`,
`OnTournamentJoined`, `OnLeaderboardUpdated`, or `OnError` when other UI needs
notifications. An awaited successful join confirms its entry; it does not confirm a
prize or authorize a client-submitted score.

Use `JoinTournamentAsync` for tournaments. Read pages with
`RequestLeaderboardAsync(tournamentId, offset: 0, limit: 20, ct: ct)`; supply a
`metricId` when your game selects a specific metric. Render the reply's entries and
`TotalEntries` rather than assuming the first page is the entire leaderboard.

Do not use `async void` outside Unity event handlers. Return `Task` from application
services so callers can await and handle failures.

### Operations

| Method | Client message | Successful reply |
|---|---|---|
| `RequestAuthAsync(email, ct)` | `auth:request` | `AuthCodeRequestedReply` |
| `SubmitCodeAsync(email, code, ct)` | `auth:submit-code` | `AuthResultReply` |
| `JoinEventAsync(eventId, ct)` | `event:join` | `EventJoinResultReply` |
| `JoinTournamentAsync(tournamentId, ct)` | `tournament:join` | `TournamentJoinResultReply` |
| `RequestLeaderboardAsync(tournamentId, metricId, offset, limit, ct)` | `tournament:leaderboard` | `LeaderboardSnapshotReply` |

See the [C# API reference](api-reference.md) for every parameter, return value, property, event, constructor, enum value, wire field, and exception.

## 8. Error handling

Handle errors at the awaited operation. `OnError` is a notification for other UI or diagnostics and is also used for unsolicited server errors.

| Exception | Action |
|---|---|
| `ArgumentException` | Correct local input before sending. |
| `GamersClientException` | Branch on `Code`; retry only when `Retryable` is true. Include `CorrelationId` in diagnostics. |
| `TimeoutException` | Offer retry or reconnect. Confirm the game-server returns one terminal reply for every request. |
| `OperationCanceledException` | Treat as expected when leaving the scene or cancelling the operation. |
| `ObjectDisposedException` | Stop using the disposed flow and create a new session flow if needed. |
| Transport exception | Apply transport-specific reconnect or offline behavior. |

Client-generated `GamersClientException.Code` values are:

- `AUTH_FAILED`
- `JOIN_EVENT_FAILED`
- `JOIN_TOURNAMENT_FAILED`
- `PROTOCOL_MISMATCH`
- `UNSUPPORTED_PROTOCOL_VERSION`

The game-server can add its own documented, player-safe error codes.

## 9. Lifecycle, concurrency, and threading

- Call public flow methods from Unity's main thread.
- Raise `IGamersTransport.ReplyReceived` on the main thread.
- One flow can have multiple outstanding requests because correlation identifiers route each reply independently.
- Avoid starting overlapping operations that compete for the same UI state unless the UI handles the resulting state transitions.
- `Dispose()` unsubscribes from the transport and cancels all outstanding operations.
- The flow does not dispose `IGamersTransport`; the caller owns its connection lifecycle.
- Set `RequestTimeout` before starting operations. Zero or a negative value disables timeout handling and should be used only when another bounded timeout exists.

## 10. Verified Solutions attribution

The package provides an Editor-only settings page for Unity Verified Solutions attribution.

1. Open **Edit → Project Settings → Gamers**.
2. Enter the non-secret Gamers developer ID from the developer portal.
3. Press Enter or select **Send Attribution Event**.
4. The page reports when the event has been accepted once for the project.

The identifier is stored in per-user `EditorUserSettings`. It is not read by runtime code and is not included in player builds. If Editor Analytics is disabled, nothing is sent. Attribution failure does not block or change the runtime client flow.

Use the Project Settings page to configure attribution.

## 11. Security checklist

Before release, verify:

- [ ] No Game API key, player JWT, or direct Game API URL appears in the client project or player build.
- [ ] The game-server authenticates the client session and derives the player identifier itself.
- [ ] Score and result submission happens only from trusted game-server logic.
- [ ] Event and tournament authorization paths remain separate.
- [ ] Every request receives exactly one terminal reply with the same correlation identifier and protocol version.
- [ ] Errors sent to the client are safe and contain no internal exception details.
- [ ] Client UI treats DTOs as display data rather than trusted authority.
- [ ] Production transport uses TLS and validates certificates normally; HTTP/REST transports use HTTPS to satisfy iOS App Transport Security.
- [ ] Logs avoid email addresses, verification codes, tokens, and other sensitive values.

## 12. Known limitations

### No production transport is included

`IGamersTransport` must be implemented with the game's authenticated networking channel. The bundled Reference Integration uses a fake transport and is a contract example, not production networking.

### No event or tournament discovery

The current flow joins competitions by identifier but does not list them. Supply available event and tournament identifiers through the game's own catalogue or backend. Keep event and tournament identifiers separate.

### No result or prize notification contract

Push results and prize notifications through the game's existing server channel. Do not submit or trust results from client code.

## 13. Reproducing failure paths

The imported `ReferenceTransport`, or your own fake transport, can exercise client
behavior without a real tenant. Use the [offline sample quick start](#offline-sample-quick-start) for a smoke test.
The installable tarball excludes test projects; when a source archive includes
`HeadlessTests`, run `dotnet test HeadlessTests/GamersClient.HeadlessTests.csproj`
from that archive's root with the .NET 8 SDK. Verify sample import and target builds
in Unity as well.

For negative-path tests, return controlled replies through your transport:

| Case | Reproduction | Expected result |
|---|---|---|
| Invalid input | Call an operation with an empty required identifier or email. | `ArgumentException` before a message is sent. |
| Timeout | Set a short positive `RequestTimeout`; accept the send and raise no reply. | `TimeoutException`; pending operation count returns to zero. |
| Cancellation | Pass a cancelled token or cancel it while waiting. | `OperationCanceledException`; pending operation is removed. |
| Server error | Raise `ErrorReply` with the request correlation identifier and protocol version `1`. | `GamersClientException`; `OnError` also fires. |
| Wrong reply type | Answer a join request with an auth reply using the matching correlation identifier. | `GamersClientException` with `PROTOCOL_MISMATCH`. |
| Wrong protocol | Return a matching reply with a version other than `1`. | `GamersClientException` with `UNSUPPORTED_PROTOCOL_VERSION`. |
| Unsuccessful auth | Return `AuthResultReply.Success == false`. | `GamersClientException` with `AUTH_FAILED`. |
| Unsuccessful event join | Return `EventJoinResultReply.Success == false`. | `GamersClientException` with `JOIN_EVENT_FAILED`. |
| Unsuccessful tournament join | Return `TournamentJoinResultReply.Success == false`. | `GamersClientException` with `JOIN_TOURNAMENT_FAILED`. |

Backend-dependent expired-code, closed-competition, and insufficient-balance scenarios require controlled test fixtures.

## 14. Dependency and data disclosure

Runtime dependency:

- `com.unity.nuget.newtonsoft-json` `3.2.1`

Player data:

- The package sends player email addresses and verification codes only through `IGamersTransport` to the developer's game-server. It does not persist them to disk.
- Treat email addresses, verification codes, user identifiers, display names, and leaderboard identifiers as sensitive or personal data where applicable. Do not include them in logs or diagnostics.
- Use only non-sensitive, intentionally public aliases and opaque identifiers in leaderboard responses. Never expose an email address, wallet address, authentication identifier, or internal account identifier as a leaderboard identity.
- The developer owns the client transport and game-server and is responsible for transport security, access controls, retention, deletion, and appropriate player-facing privacy notices.

Editor-only telemetry:

- Unity Verified Solutions attribution sends action name, partner name, and the non-secret Gamers developer identifier through Unity Editor Analytics.
- It respects the user's Editor Analytics preference.
- No player email, verification code, Game API key, JWT, or gameplay result is sent by the attribution integration.

The Gamers backend service is governed separately from the Unity package. Review the service terms presented during Gamers account registration.

## 15. Support

Contact `support@gamers.dev`. Include:

- package version
- Unity version, platform, architecture, and scripting backend
- transport implementation and connection state
- exception type and `GamersClientException.Code`
- request `CorrelationId`
- non-secret game-server request or trace identifier when available

Do not send API keys, JWTs, session tokens, cookies, verification codes, email addresses, or other player credentials in a support request.
