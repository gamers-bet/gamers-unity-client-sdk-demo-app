# Game API integration

The Game API is called by your game server. Unity clients use the message protocol
in the bundled [integration guide](integration-guide.md).

1. Register your studio and game in the [Developer Portal](https://developer.gamers.dev/).
2. Configure gameplay modes and metrics, then keep your game's API key on your server.
3. Point that server at the test API, `https://api.gamers.dev`.
4. Authenticate players through your game server. The Unity flow requests an email
   code and submits it; your server stores the resulting Game API authentication.
5. Supply event or tournament IDs to the client, validate each join on the server,
   and submit only server-validated scores and results.

Use the [Game API Developer Guide](https://developer.gamers.dev/docs/dev-guide)
for requests, errors, competition lifecycles, and test setup. It requires a developer
account. The complete Unity usage guide and C# API reference are bundled here;
a connection to the Developer Portal is not needed to read them.
