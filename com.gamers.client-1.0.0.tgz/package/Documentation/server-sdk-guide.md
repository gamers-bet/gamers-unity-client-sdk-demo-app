# Connecting a server SDK

Use the Java or .NET Server SDK in your game server. Do not add either SDK or its
credentials to a Unity player build. The Unity package uses `IGamersTransport` to
call your server instead.

Configure the server SDK with your game API key and `https://api.gamers.dev`.
Keep a separate player token for each authenticated game session. Derive that
session identity from your own authentication rather than accepting a player ID
from a Unity message.

| Unity request | Server responsibility |
|---|---|
| `auth:request` | Request the player's email verification code |
| `auth:submit-code` | Verify the code and store the player's token on the server |
| `event:join` | Authorize the player and request that event entry |
| `tournament:join` | Authorize the player and request that tournament entry |
| `tournament:leaderboard` | Fetch and return a page of safe display data |

Return the matching reply type, `protocolVersion: 1`, and the original
`correlationId`. Send a safe `ErrorReply` for failure, so client calls do not wait
until timeout. The [C# API reference](api-reference.md) defines the wire fields.

Follow the [Server SDK Guide](https://developer.gamers.dev/docs/server-sdk-guide)
for installation, API key configuration, token storage, retries, and Java/.NET
examples. The [reference server guide](https://developer.gamers.dev/docs/reference-server-guide)
provides a runnable test bridge. Both online server guides require a developer account.
