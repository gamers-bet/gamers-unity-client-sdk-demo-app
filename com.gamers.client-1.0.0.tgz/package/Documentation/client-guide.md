# Unity client quick start

This guide uses only files included in `com.gamers.client`. For all public methods
and wire fields, see the [C# API reference](api-reference.md).

## Try the offline sample

1. Install the package through Unity Package Manager using the supplied `package.json`
   or `.tgz`. Use Unity 2022.3 LTS or newer.
2. Select **Gamers Client Helper → Samples → Reference Integration → Import**.
3. In a scene, create an empty GameObject and add the imported `ReferenceIntegration`
   component. Enter Play mode so its session is initialized.
4. Connect your UI's submit/click events to the handlers below. String fields or
   dynamic string events provide each value. `OnSubmitCode` takes two strings;
   call it from your own UI handler that reads both input fields.

| Order | Handler | Synthetic input | Expected output in the Console |
|---|---|---|---|
| 1 | `OnRequestAuth(email)` | `player@example.invalid` | Code-request acknowledgement |
| 2 | `OnSubmitCode(email, code)` | Same email and any test code | Authenticated reply |
| 3 | `OnJoinEvent(eventId)` | `sample-event` | An event entry ID |
| Alternative to 3 | `OnJoinTournament(tournamentId)` | `sample-tournament` | A tournament entry ID |
| 4 | `OnShowLeaderboard(tournamentId)` | `sample-tournament` | A leaderboard with one sample entry |

The sample simulates success locally. It sends no email, makes no real join or
payment, and proves no game-server connectivity. Its message logging includes
inputs, so use only synthetic test values.

## Connect your game

1. Prepare a game server with the [server SDK guide](https://developer.gamers.dev/docs/server-sdk-guide)
   or [reference server guide](https://developer.gamers.dev/docs/reference-server-guide).
2. Authenticate your game's client/server connection. Keep the Game API key and
   player JWT on the server; the Unity package needs neither credential.
3. Implement `IGamersTransport` using your networking system. The
   [integration guide](integration-guide.md#6-implement-igamerstransport) includes a
   JSON adapter that accepts your send and main-thread dispatch functions.
4. Create `GamersClientFlow` with that transport. Request a code, collect it from
   the player, call `SubmitCodeAsync`, then await an event or tournament join.
5. Provide competition IDs from your game's own catalogue. This client flow does
   not list events or tournaments. The server validates membership and results.
6. Cancel pending calls and dispose the flow when leaving the session. Close your
   transport separately; the flow does not own the connection.

For scripts in your own assembly definition, reference `GamersClient.Runtime` and,
if using the JSON adapter, `Unity.Newtonsoft.Json`.

## Check the connection

- A timeout means no matching terminal reply arrived. Check the server's message
  handler and that your transport raises `ReplyReceived` on Unity's main thread.
- Each reply must preserve the request's `correlationId` and `protocolVersion: 1`.
- Handle `GamersClientException.Code`, cancellation, and timeout separately.
  Surface safe messages to players; keep credentials and verification codes out of logs.
- Test reconnects and scene changes while a request is pending.
- Build and run on each target platform, including an IL2CPP build when used.

See [error handling](integration-guide.md#8-error-handling),
[failure-path checks](integration-guide.md#13-reproducing-failure-paths), and the
[online client guide](https://developer.gamers.dev/docs/client-sdk-guide).
