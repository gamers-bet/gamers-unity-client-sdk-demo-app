# Gamers Unity Client Helper

Unity package for sign-in, event and tournament entry, and leaderboards through your
own game server. It does not call the Game API directly. Keep Game API keys and
player JWTs on your server.

## Requirements

- Unity 2022.3 LTS or newer, with the .NET Standard 2.1 profile.
- Windows, macOS, ARM64 Android, or iOS; Mono or IL2CPP.
- Your own authenticated game-server connection implementing `IGamersTransport`.
- `com.unity.nuget.newtonsoft-json` 3.2.1, installed automatically by Unity Package Manager.

## Install

Extract the supplied ZIP, keep its files on disk, and choose this package's
`package.json` in **Window → Package Manager → + → Add package from disk**.
For a supplied `.tgz`, choose **Add package from tarball**.

Select **Gamers Client Helper → Samples → Reference Integration → Import** to try
its simulated player flow. It works offline and sends no email or real payment.
Use synthetic test values: the sample prints its messages to the Unity Console.

Start with the [client quick start](Documentation/client-guide.md), then use the
[integration guide](Documentation/integration-guide.md) to connect your server.
All Unity usage instructions are included in this package.

## Included files

| Path | Use |
|---|---|
| `Runtime/` | Public client types and request/reply contracts |
| `Editor/` | Gamers developer attribution settings |
| `Samples~/ReferenceIntegration/` | Importable simulated transport and UI handlers |
| `Documentation/` | Setup, examples, C# API reference, and server integration guidance |
| `link.xml` | Preservation settings for IL2CPP builds |

The installable package does not include a production transport or the separate
test projects. A source download may include tests beside the package.

- [C# API reference](Documentation/api-reference.md)
- [Release notes](CHANGELOG.md)
- [License](LICENSE.pdf) and [third-party notices](<Third Party Notices.md>)
- [Online client guide](https://developer.gamers.dev/docs/client-sdk-guide)
- [Server SDK guide](https://developer.gamers.dev/docs/server-sdk-guide)

Support: `support@gamers.dev`.
